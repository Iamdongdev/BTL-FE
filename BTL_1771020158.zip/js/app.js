$(document).ready(function() {
    // Smooth scroll for links
    $('.navbar a').on('click', function(e) {
        if (this.hash !== '') {
            e.preventDefault();
            var hash = this.hash;
            $('html, body').animate({
                scrollTop: $(hash).offset().top
            }, 800);
        }
    });

    // Highlight the current section in the navbar
    $(window).on('scroll', function() {
        var scrollPosition = $(this).scrollTop();
        $('.navbar a').each(function() {
            var sectionOffset = $(this.hash).offset().top;
            if (sectionOffset <= scrollPosition) {
                $('.navbar a').removeClass('active');
                $(this).addClass('active');
            }
        });
    });
});
