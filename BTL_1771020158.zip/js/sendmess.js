document.addEventListener('DOMContentLoaded', () => {
    const name = document.getElementById('name');
    const mail = document.getElementById('mail');
    const subject = document.getElementById('subject');
    const content = document.getElementById('content');
    const submit = document.getElementById('submit');
    const notification = document.getElementById('notification');

    submit.addEventListener('click', (e) => {
        e.preventDefault();
        
        const data = {
            name: name.value,
            mail: mail.value,
            subject: subject.value,
            content: content.value,
        };

        postGoogle(data);
    });

    async function postGoogle(data) {
        const formURL = "https://docs.google.com/forms/u/0/d/e/1FAIpQLSd8USgQo-K4f1R28JbeJZfGVeOmQXskSEINDpnc8HSppXUGsw/formResponse";
        const formData = new FormData();
        formData.append('entry.1318413496', data.name); // Thay thế đúng với entry ID trong Google Forms
        formData.append('entry.1004758389', data.mail); // Thay thế đúng với entry ID trong Google Forms
        formData.append('entry.1902819560', data.subject); // Thay thế đúng với entry ID trong Google Forms
        formData.append('entry.1558843997', data.content); // Thay thế đúng với entry ID trong Google Forms

        try {
            const response = await fetch(formURL, {
                method: 'POST',
                mode: 'no-cors', // 'no-cors' để không bị chặn bởi chính sách CORS
                body: formData,
            });

            if (response) {
                notification.classList.add('show');
                setTimeout(() => {
                    notification.classList.remove('show');
                }, 3000); // Ẩn thông báo sau 3 giây
                console.log('Form successfully submitted');
            } else {
                console.log('Error submitting the form');
            }
        } catch (error) {
            console.error('Error:', error);
        }
    }
});